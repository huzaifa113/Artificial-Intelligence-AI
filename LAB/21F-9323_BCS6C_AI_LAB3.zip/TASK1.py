class Bus:
    def __init__(self, capacity=34, female_capacity=17, male_capacity=17):
        self.capacity = capacity
        self.capacity_added=0
        self.female_capacity = female_capacity
        self.male_capacity = male_capacity
        self.female_added = 0
        self.male_added = 0
        self.students = []

    def add_student(self, name, gender):
        if self.capacity_added<self.capacity:
            if gender == 'female' and self.female_added < self.capacity:
                seat_number = self.female_added + 1
                self.students.append({'name': name, 'gender': 'female', 'seat_number': seat_number})
                print(f"{name} added to the bus. Seat number: {seat_number}")
                self.female_added += 1
                self.capacity_added += 1
            elif gender == 'male' and self.male_added < self.male_capacity:
                seat_number = self.male_added + 1
                self.students.append({'name': name, 'gender': 'male', 'seat_number': seat_number})
                print(f"{name} added to the bus. Seat number: {seat_number}")
                self.male_added += 1
                self.capacity_added += 1

            else:
                print(f"Cannot add {name}. No more seats available for {gender} students.")

        else:
            print(f"Cannot add {name}. No more seats available in bus.")

    def show_students(self):
        print("\nStudents on the bus:")
        for student in self.students:
            print(f"Seat {student['seat_number']}: {student['name']} ({student['gender']})")

    def drop_students(self):
        print("\nDropping students at the department.")
        self.students = []


# Example usage
bus = Bus()

# Adding students to the bus
bus.add_student("Sara", "female")
bus.add_student("Ali", "male")
bus.add_student("Ahmad", "male")
bus.add_student("Zainab", "female")
bus.add_student("Maryam", "female")


bus.show_students()


bus.drop_students()


bus.show_students()
