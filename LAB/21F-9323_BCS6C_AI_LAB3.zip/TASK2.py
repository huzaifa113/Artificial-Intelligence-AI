graph = {
    'dunwich': {'blaxhall': 15, 'harwich': 53},
    'blaxhall': {'dunwich': 15, 'harwich': 40, 'feering': 46},
    'harwich': {'dunwich': 53, 'blaxhall': 40, 'clacton': 17},
    'feering': {'blaxhall': 46, 'tiptree': 3, 'maldon': 11},
    'tiptree': {'feering': 3, 'harwich': 31, 'clacton': 29, 'maldon': 8},
    'clacton': {'harwich': 17, 'tiptree': 29, 'maldon': 40},
    'maldon': {'feering': 11, 'tiptree': 8, 'clacton': 40}
}

for node, edges in graph.items():
    print(f"{node} -> {edges}")
