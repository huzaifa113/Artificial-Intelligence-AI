graph = {
    1: [2, 3],
    2: [4, 5],
    3: [6, 7],
    4: [],
    5: [],
    6: [],
    7: []
}


for node, children in graph.items():
    print(f"{node} -> {children}")
