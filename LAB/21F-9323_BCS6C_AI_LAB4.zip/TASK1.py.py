graph = [('A', 'B', 'E', 'C'),
         ('B', 'A', 'E', 'D'),
         ('C', 'F', 'G'),
         ('D', 'B', 'E'),
         ('E', 'B', 'D'),
         ('F', 'C'),
         ('G', 'C')]


nodes = sorted(set(node for edge in graph for node in edge))

# Create an empty adjacency matrix filled with zeros
adjacency_matrix = [[0] * len(nodes) for _ in range(len(nodes))]

# Populate the adjacency matrix based on the edges in the graph
for edge in graph:
    from_node = edge[0]
    for to_node in edge[1:]:
        from_index = nodes.index(from_node)
        to_index = nodes.index(to_node)
        adjacency_matrix[from_index][to_index] = 1

# Print the adjacency matrix
for row in adjacency_matrix:
    print(' '.join(map(str, row)))