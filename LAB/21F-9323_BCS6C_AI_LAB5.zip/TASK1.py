def heuristic(node, goal):
    x1, y1 = node
    x2, y2 = goal
    return abs(x1 - x2) + abs(y1 - y2)

def get_neighbors(node, maze):
    x, y = node
    neighbors = [
         (x+1, y), (x-1, y), (x, y+1), (x, y-1)
    ]
    valid_neighbors = [
        (nx, ny) for nx, ny in neighbors
        if 0 <= nx < len(maze) and 0 <= ny < len(maze[0]) and maze[nx][ny] != ' '
    ]
    return valid_neighbors

def hill_climbing(maze, start, goal):
    current_node = start
    path = [current_node]

    while current_node != goal:
        neighbors = get_neighbors(current_node, maze)
        if not neighbors:
            break

        neighbor_costs = {neighbor: heuristic(neighbor, goal) for neighbor in neighbors}
        best_neighbor = min(neighbor_costs, key=neighbor_costs.get)

        if heuristic(best_neighbor, goal) >= heuristic(current_node, goal):
            # If no better neighbor is found, break the loop
            break

        current_node = best_neighbor
        path.append(current_node)

    return path


maze = [
    [' ', ' ', 'W', ' ', 'X', 'Y'],
    ['R', 'S', 'T', 'U', ' ', 'V'],
    ['M', 'N', ' ', 'O', 'P', 'Q'],
    ['H', 'I', 'J', ' ', 'K', 'L'],
    ['F', ' ', 'G', ' ', ' ', ' '],
    ['A', ' ', 'B', 'C', 'D', 'E']
]


start_position = (5, 0)  
goal_position = (0, 5)   


hill_climbing_path = hill_climbing(maze, start_position, goal_position)


print("Path found:", hill_climbing_path)
