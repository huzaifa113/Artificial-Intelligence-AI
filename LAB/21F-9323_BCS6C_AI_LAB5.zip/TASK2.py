import random

def objective_function(x):
    return x**2 - 4*x + 4

def hill_climbing(initial_position, step_size, max_iterations):
    current_position = initial_position

    for _ in range(max_iterations):
        current_value = objective_function(current_position)

        # Check neighboring points
        next_positions = [current_position - step_size, current_position, current_position + step_size]
        next_values = [objective_function(pos) for pos in next_positions]

        # Move to the position with a higher (for maximum) or lower (for minimum) value
        if current_value == max(next_values):
            current_position = next_positions[next_values.index(max(next_values))]
        elif current_value == min(next_values):
            current_position = next_positions[next_values.index(min(next_values))]
        else:
            # If current position is not the maximum or minimum, break the loop
            break

    return current_position, objective_function(current_position)

# Initialize random starting point within the range [-10, 10]
initial_point = random.uniform(-10, 10)

# Set step size and maximum iterations
step_size = 0.1
max_iterations = 100

# Run Hill Climbing algorithm
max_position, max_value = hill_climbing(initial_point, step_size, max_iterations)

# Output results for maximum
print(f"Maximum value found at position {max_position}, with value {max_value}")

# Run Hill Climbing algorithm for minimum
min_position, min_value = hill_climbing(initial_point, -step_size, max_iterations)

# Output results for minimum
print(f"Minimum value found at position {min_position}, with value {min_value}")
