graph = {
    'A': ['B', 'C', 'D'],
    'B': ['E', 'F', 'G'],
    'C': ['H', 'I', 'J'],
    'D': ['K', 'L', 'M'],
    'E': [],
    'F': [],
    'G': [],
    'H': [],
    'I': [],
    'J': [],
    'K': [],
    'L': [],
    'M': []
}

cost = {
    'A': 3,
    'B': 3,
    'C': 2,
    'D': 2,
    'E': 3,
    'F': 12,
    'G': 8,
    'H': 2,
    'I': 4,
    'J': 6,
    'K': 14,
    'L': 5,
    'M': 2,
}


class Minmax:
    def __init__(self, graph, cost):
        self.graph = graph
        self.cost = cost
        self.nodes_explored = 0

    def min_max(self, node, is_maximizing):
        self.nodes_explored += 1

        if self.graph[node] == []:
            return self.cost[node], [node]

        if is_maximizing:
            max_eval = float('-inf')
            best_path = []
            for child in self.graph[node]:
                eval_child, path_child = self.min_max(child, False)
                if eval_child > max_eval:
                    max_eval = eval_child
                    best_path = [node] + path_child
            return max_eval, best_path

        else:
            min_eval = float('inf')
            best_path = []
            for child in self.graph[node]:
                eval_child, path_child = self.min_max(child, True)
                if eval_child < min_eval:
                    min_eval = eval_child
                    best_path = [node] + path_child
            return min_eval, best_path

    def find_optimal_path(self, start_node):
        optimal_path_cost, optimal_path = self.min_max(start_node, True)
        return optimal_path_cost, optimal_path




minimax = Minmax(graph, cost)
optimal_path_cost, optimal_path = minimax.find_optimal_path('A')
print("Optimal Path:", ' -> '.join(optimal_path))
print("Optimal Path Cost:", optimal_path_cost)
print("Space Complexity: 2 (Depth)")
print("Time complexity:", minimax.nodes_explored)

