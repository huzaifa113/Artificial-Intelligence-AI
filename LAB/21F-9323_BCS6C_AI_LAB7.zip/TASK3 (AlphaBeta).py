graph = {
    'A': ['B', 'C', 'D'],
    'B': ['E', 'F', 'G'],
    'C': ['H', 'I', 'J'],
    'D': ['K', 'L', 'M'],
    'E': [],
    'F': [],
    'G': [],
    'H': [],
    'I': [],
    'J': [],
    'K': [],
    'L': [],
    'M': []
}

cost = {
    'A': 3,
    'B': 3,
    'C': 2,
    'D': 2,
    'E': 3,
    'F': 12,
    'G': 8,
    'H': 2,
    'I': 4,
    'J': 6,
    'K': 14,
    'L': 5,
    'M': 2,
}


class MinMaxAlphaBeta:
    def __init__(self, graph, cost):
        self.graph = graph
        self.cost = cost
        self.nodes_explored = 0

    def minimax_alpha_beta(self, node, is_maximizing, alpha, beta):
        self.nodes_explored += 1

        if not self.graph[node]:
            return self.cost[node], [node]

        if is_maximizing:
            max_eval = float('-inf')
            best_path = []
            for child in self.graph[node]:
                eval_child, path_child = self.minimax_alpha_beta(child, False, alpha, beta)
                if eval_child > max_eval:
                    max_eval = eval_child
                    best_path = [node] + path_child
                alpha = max(alpha, max_eval)
                if alpha >= beta:
                    break
            return max_eval, best_path

        else:
            min_eval = float('inf')
            best_path = []
            for child in self.graph[node]:
                eval_child, path_child = self.minimax_alpha_beta(child, True, alpha, beta)
                if eval_child < min_eval:
                    min_eval = eval_child
                    best_path = [node] + path_child
                beta = min(beta, min_eval)
                if beta <= alpha:
                    break
            return min_eval, best_path

    def find_optimal_path(self, start_node):
        optimal_path_cost, optimal_path = self.minimax_alpha_beta(start_node, True, float('-inf'), float('inf'))
        return optimal_path_cost, optimal_path


minimax_alpha_beta = MinMaxAlphaBeta(graph, cost)
optimal_path_cost, optimal_path = minimax_alpha_beta.find_optimal_path('A')
print("Optimal Path:", ' -> '.join(optimal_path))
print("Optimal Path Cost:", optimal_path_cost)
print("Space Complexity: 2 (Depth)")
print("Nodes Explored:", minimax_alpha_beta.nodes_explored)
