graph = {
    "A": {"B": 5,  "C": 10},
    "B": {"D": 3,  "E": 9},
    "C": {"D": 8},
    "D": {"E": 2},
}

for node, edges in graph.items():
    print(f"{node} -> {edges}")







