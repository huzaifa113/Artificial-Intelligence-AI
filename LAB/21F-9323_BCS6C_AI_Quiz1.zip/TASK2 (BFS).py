from queue import deque

graph = {
    "A": {"B": 5,  "C": 10},
    "B": {"D": 3,  "E": 9},
    "C": {"D": 8},
    "D": {"E": 2},
}


def bfs(graph, start, goal):
    queue = deque([(start, [start])])
    visited = set()

    while queue:
        current_node, path = queue.popleft()

        if current_node == goal:
            return path

        if current_node not in visited:
            visited.add(current_node)
            queue.extend((neighbor, path + [neighbor]) for neighbor in graph[current_node])

    return None


bfs_path = bfs(graph, 'A', 'E')

print("\nBreadth-First Search:")
print("Path:", bfs_path)