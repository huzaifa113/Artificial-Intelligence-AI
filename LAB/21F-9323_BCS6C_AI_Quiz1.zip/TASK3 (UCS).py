from queue import PriorityQueue

graph = {
    "A": {"B": 5,  "C": 10},
    "B": {"D": 3,  "E": 9},
    "C": {"D": 8},
    "D": {"E": 2},
}


def ucs(graph, start, goal):
    queue = PriorityQueue()
    queue.put((0, [start]))

    while not queue.empty():
        cost, path = queue.get()
        current_node = path[-1]

        if current_node == goal:
            return path, cost

        for neighbor, edge_cost in graph[current_node].items():
            new_path = path + [neighbor]
            new_cost = cost + edge_cost
            queue.put((new_cost, new_path))


shortest_path, total_cost = ucs(graph, 'A', 'E')

print("\nUniform Cost Search:")
print("Path:", shortest_path)
print("Total cost:", total_cost)