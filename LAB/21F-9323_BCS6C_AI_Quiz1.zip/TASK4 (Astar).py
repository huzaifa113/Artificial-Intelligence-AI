from queue import PriorityQueue

graph = {
    "A": {"B": 5,  "C": 10},
    "B": {"D": 3,  "E": 9},
    "C": {"D": 8},
    "D": {"E": 2},
}


def heuristic(node, goal):
    x1, y1 = node
    x2, y2 = goal
    return abs(x1 - x2) + abs(y1 - y2)



def Astar(graph, start, goal):
    queue = PriorityQueue()
    queue.put((0, start, []))

    while not queue.empty():
        cost, current_node, path = queue.get()

        if current_node == goal:
            return path + [current_node]

        for neighbor, edge_cost in graph[current_node].items():
            new_cost = cost + edge_cost
            priority = new_cost + heuristic(node,goal)
            queue.put((priority, node, path + [current_node]))

    return None


path = Astar(graph, 'A', 'E')

print("\nA Star Search:")
if path:
    print("Path:", shortest_path)
else:
    print("No Path found")
